// src/utils/schemaVersioning.js

export const createVersionSnapshot = (tree, versionTag, description = '') => {
  return {
    id: typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID()
      : Math.random().toString(36).substring(2, 9),
    versionTag,
    description,
    timestamp: new Date().toISOString(),
    tree: JSON.parse(JSON.stringify(tree || [])),
  };
};

export const saveVersionsToStorage = (storageKey, versions) => {
  try {
    localStorage.setItem(storageKey, JSON.stringify(versions || []));
  } catch (err) {
    console.error('Failed to save versions to localStorage:', err);
  }
};

export const loadVersionsFromStorage = (storageKey) => {
  try {
    const raw = localStorage.getItem(storageKey);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Failed to load versions from localStorage:', err);
    return [];
  }
};
