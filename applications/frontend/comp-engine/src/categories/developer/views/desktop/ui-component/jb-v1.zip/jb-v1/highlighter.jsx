const Comp = (props) => {
    const {text, search} = props;

    if (!search.trim()) {
        return text;
    }else{
        const escapedSearch = search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        const regex = new RegExp(`(${escapedSearch})`, 'gi');
        const parts = text.split(regex);
        return parts.map((part, index) => {
            if(regex.test(part)){
                return <mark key={index} className="bg-yellow-200 text-yellow-900 rounded-sm px-0.5 font-bold">{part}</mark>   
            }else{
                return part;
            }
        });
    }
};

export default Comp;
