import NodeRow from './node-row';
import Input from 'aio-global-raw-ui/atoms/form/input';
import {useState, useMemo, useEffect, useCallback} from 'react';

const Comp = (props) => {
    const {
  initialNodes,
  onChange,
  renderCustomMetaAttribute,
  getIconByType,
} = props;

  const builder = props.builder;

  const defaultTree = useMemo(() => [
    builder.createNode('userId', 'number', { required: true, dvalue: 1001, value: 1001, isExpanded:true, customMeta:[{id:'sss', key:'sandeep', value:'kundu'}]}),
    {
      ...builder.createNode('userConfig', 'object', { required: true }),
      children: [
        builder.createNode('theme_mode', 'string', { required: false, dvalue: 'dark', value: 'dark' }),
      ],
    },
  ], []);

  const [history, setHistory] = useState([defaultTree]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const tree = history[historyIndex] || [];

  const [versions, setVersions] = useState(() => builder.version.load());
  const [showVersionModal, setShowVersionModal] = useState(false);
  const [newVersionTag, setNewVersionTag] = useState('');
  const [newVersionDesc, setNewVersionDesc] = useState('');

  const [searchQuery, setSearchQuery] = useState('');
  const [draggedParentType, setDraggedParentType] = useState(null);

  const commitTreeChange = useCallback((newTree) => {
    setHistory((prevHistory) => {
      const updatedHistory = prevHistory.slice(0, historyIndex + 1);
      return [...updatedHistory, newTree];
    });
    setHistoryIndex((prevIndex) => prevIndex + 1);
  }, [historyIndex]);

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) setHistoryIndex((prev) => prev - 1);
  }, [historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) setHistoryIndex((prev) => prev + 1);
  }, [historyIndex, history.length]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        if (e.shiftKey) handleRedo();
        else handleUndo();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
        handleRedo();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);

  useEffect(() => {
    builder.version.save(versions);
  }, [versions]);

  const handleSearchChange = (e) => {
    const q = e.target.value;
    setSearchQuery(q);
    if (q.trim()) {
      commitTreeChange(builder.expandMatching(tree, q));
    }
  };

  const isValid = useMemo(() => builder.isTreeValid(tree), [tree]);

    useEffect(() => {
     helpers.react.hooks.event.emit('PREVIEW_JSON_DATA', {
        json:tree,
        valid:isValid
     });

    //if (onChange) onChange(res, tree, isValid);
    //return res;
  }, [tree, isValid, onChange]);

  const handleUpdate = (id, updater) => {
    commitTreeChange(builder.updateNode(tree, id, updater));
  };

  const handleDelete = (id) => {
    commitTreeChange(builder.deleteNode(tree, id));
  };

  const handleAddChild = (parentId, child) => {
    commitTreeChange(builder.addChildNode(tree, parentId, child));
  };

  const handleAddRootField = () => {
    commitTreeChange([...tree, builder.createNode('', 'string')]);
  };

  const handleReorder = (draggedId, targetParentId, targetIndex) => {
    const { cleanedTree, draggedNode } = builder.extractNode(tree, draggedId);
    if (!draggedNode) return;
    const reorderedTree = builder.insertAtActiveLevel(cleanedTree, targetParentId, draggedNode, targetIndex);
    commitTreeChange(reorderedTree);
  };

  const handleReparent = (draggedId, targetParentId) => {
    commitTreeChange(builder.reparentNode(tree, draggedId, targetParentId));
  };

  const handleSaveVersion = (e) => {
    e.preventDefault();
    if (!newVersionTag.trim()) return;
    const snapshot =  builder.version.create(tree, newVersionTag.trim(), newVersionDesc.trim());
    setVersions((prev) => [snapshot, ...prev]);
    setNewVersionTag('');
    setNewVersionDesc('');
  };

  const handleRestoreVersion = (snapshot) => {
    if (window.confirm(`Restore schema to checkpoint "${snapshot.version}"?`)) {
      commitTreeChange(JSON.parse(JSON.stringify(snapshot.tree)));
      setShowVersionModal(false);
    }
  };

  const handleDeleteVersion = (snapshotId) => {
    setVersions((prev) => prev.filter((v) => v.id !== snapshotId));
  };

  return (
        <div className='full bxs bg-c00101 pd-16 bdr-1 bdr-c00104 bdr-8'>
            <div className='full bxs pd-b16'>
                <h3 className='full bxs txt-sm fm-md'>Schema Field Editor</h3>
                {!isValid && (<span className='txt-xxs mr-t8 txt-c00306'>⚠️ Resolve empty or duplicate keys before compiling</span>)}
            </div>
            <div className='full flx-vc grid-wrapper'>
                <div className='grid-w6'>
                    <Input
                        clearable={true}
                        value={searchQuery}
                        placeholder="Search schema..."
                        callback={{
                            onChangeStart:(val) => {
                                handleSearchChange({
                                    target:{
                                        value:val
                                    }
                                })
                            }
                        }}
                    />
                </div>
                <div className='grid-w6 flx-sb bxs pd-rl16'>
                    <span className={`cp txt-xs txt-${(historyIndex === 0)?'c00104':"c00107"}`} onClick={handleUndo}>Undo</span>
                    <span className={`cp txt-xs txt-${(historyIndex >= history.length - 1)?'c00104':"c00107"}`} onClick={handleRedo}>Redo</span>
                    <span className={`cp txt-xs txt-c00107 link`} onClick={() => setShowVersionModal(true)}> Versions ({versions.length})</span>
                    <span className={`cp txt-xs txt-c00107 link`} onClick={handleAddRootField}>+ Add Root Field</span>
                </div>
            </div>

            <div className='full bxs'>
                {(tree || []).map((node, index) => (
                    <NodeRow
                        key={node.id}
                        node={node}
                        depth={0}
                        parentType="object"
                        index={index}
                        parentId="root"
                        onUpdate={handleUpdate}
                        onDelete={handleDelete}
                        onAddChild={handleAddChild}
                        entireTree={tree}
                        isSiblingKeyDuplicateFn={builder.isDuplicate}
                        onReorder={handleReorder}
                        onReparent={handleReparent}
                        draggedParentType={draggedParentType}
                        setDraggedParentType={setDraggedParentType}
                        searchQuery={searchQuery}
                        renderCustomMetaAttribute={renderCustomMetaAttribute}
                        getIconByType={getIconByType}
                        builder={props.builder}
                    />
                ))}
            </div>


      {/* Version History Checkpoint Modal */}
      {showVersionModal && (
        <div style={modalBackdropStyle}>
          <div style={modalContentStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ margin: 0, fontSize: '18px', color: '#0f172a' }}>Schema Version Checkpoints</h3>
              <button
                type="button"
                onClick={() => setShowVersionModal(false)}
                style={{ border: 'none', background: 'transparent', fontSize: '18px', cursor: 'pointer' }}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveVersion} style={versionFormStyle}>
              <h4 style={{ margin: '0 0 8px 0', fontSize: '13px', color: '#334155' }}>Save Named Checkpoint</h4>
              <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
                <input
                  type="text"
                  placeholder="Version Tag (e.g. v1.0.0)"
                  value={newVersionTag}
                  onChange={(e) => setNewVersionTag(e.target.value)}
                  style={{ ...inputStyle, width: '150px' }}
                  required
                />
                <input
                  type="text"
                  placeholder="Description of changes"
                  value={newVersionDesc}
                  onChange={(e) => setNewVersionDesc(e.target.value)}
                  style={{ ...inputStyle, flex: 1 }}
                />
                <button
                  type="submit"
                  style={{
                    padding: '6px 12px',
                    backgroundColor: '#10b981',
                    color: '#ffffff',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontWeight: 600,
                  }}
                >
                  Save Checkpoint
                </button>
              </div>
            </form>

            <div style={{ maxHeight: '350px', overflowY: 'auto' }}>
              {versions.length === 0 ? (
                <p style={{ textAlign: 'center', color: '#94a3b8', fontSize: '13px', margin: '24px 0' }}>
                  No saved version checkpoints yet.
                </p>
              ) : (
                versions.map((ver) => (
                  <div key={ver.id} style={versionItemStyle}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={versionTagBadgeStyle}>{ver.version}</span>
                        <span style={{ fontSize: '11px', color: '#64748b' }}>
                          {new Date(ver.timestamp).toLocaleString()}
                        </span>
                      </div>
                      {ver.description && (
                        <p style={{ margin: '4px 0 0 0', fontSize: '12px', color: '#475569' }}>
                          {ver.description}
                        </p>
                      )}
                    </div>

                    <div style={{ display: 'flex', gap: '8px' }}>
                      <button
                        type="button"
                        onClick={() => handleRestoreVersion(ver)}
                        style={restoreButtonStyle}
                      >
                        Restore
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteVersion(ver.id)}
                        style={deleteSnapshotButtonStyle}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const modalBackdropStyle = {
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: 'rgba(15, 23, 42, 0.6)',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 1000,
};

const modalContentStyle = {
  background: '#ffffff',
  padding: '24px',
  borderRadius: '8px',
  width: '600px',
  maxWidth: '90%',
  boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)',
};

const versionFormStyle = {
  background: '#f8fafc',
  padding: '12px',
  borderRadius: '6px',
  border: '1px solid #e2e8f0',
  marginBottom: '16px',
};

const inputStyle = {
  padding: '6px 10px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  fontSize: '12px',
};

const versionItemStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '10px 12px',
  borderRadius: '6px',
  border: '1px solid #e2e8f0',
  marginBottom: '8px',
  background: '#ffffff',
};

const versionTagBadgeStyle = {
  fontWeight: 'bold',
  fontSize: '12px',
  backgroundColor: '#eff6ff',
  color: '#2563eb',
  padding: '2px 8px',
  borderRadius: '4px',
  border: '1px solid #bfdbfe',
};

const restoreButtonStyle = {
  padding: '4px 10px',
  backgroundColor: '#2563eb',
  color: '#ffffff',
  border: 'none',
  borderRadius: '4px',
  fontSize: '11px',
  fontWeight: 600,
  cursor: 'pointer',
};

const deleteSnapshotButtonStyle = {
  padding: '4px 8px',
  backgroundColor: 'transparent',
  color: '#ef4444',
  border: '1px solid #fca5a5',
  borderRadius: '4px',
  fontSize: '11px',
  cursor: 'pointer',
};

export default Comp;