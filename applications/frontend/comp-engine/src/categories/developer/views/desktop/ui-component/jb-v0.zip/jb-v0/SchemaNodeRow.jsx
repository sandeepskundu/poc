// src/components/SchemaNodeRow.jsx
import React, { useState } from 'react';
import {
  ALPHANUMERIC_REGEX,
  DATA_TYPES,
  createDefaultNode,
  getDefaultValueForType,
  nodeMatchesQuery,
} from './schemaTree';

export const SchemaNodeRow = ({
  node,
  depth,
  parentType,
  index,
  parentId = 'root',
  onUpdate,
  onDelete,
  onAddChild,
  entireTree,
  isSiblingKeyDuplicateFn,
  onReorder,
  onReparent,
  draggedParentType,
  setDraggedParentType,
  searchQuery,
}) => {
  const isObjectOrArray = node.type === 'object' || node.type === 'array';
  const isParentArray = parentType === 'array';

  // Drag states
  const [dragOverPosition, setDragOverPosition] = useState(null); // 'before' | 'after' | 'inside' | null
  const [isDragging, setIsDragging] = useState(false);

  // Search filtering logic
  const query = (searchQuery || '').trim().toLowerCase();
  const isMatchInBranch = query ? nodeMatchesQuery(node, query) : true;
  const isDirectMatch = query && (
    (node.key || '').toLowerCase().includes(query) ||
    (node.type || '').toLowerCase().includes(query) ||
    String(node.value || '').toLowerCase().includes(query) ||
    (node.customMeta && node.customMeta.some((meta) =>
      (meta.key || '').toLowerCase().includes(query) ||
      String(meta.value || '').toLowerCase().includes(query)
    ))
  );

  // Validation
  const hasDuplicateError = !isParentArray && isSiblingKeyDuplicateFn(entireTree, node.id, node.key);
  const hasEmptyError = !isParentArray && (!node.key || !node.key.trim());
  const hasError = hasDuplicateError || hasEmptyError;

  // Drop compatibility
  const isDropAllowed = draggedParentType === null || draggedParentType === parentType;

  const handleKeyChange = (e) => {
    const rawVal = e.target.value;
    if (ALPHANUMERIC_REGEX.test(rawVal)) {
      onUpdate(node.id, (prev) => ({ ...prev, key: rawVal }));
    }
  };

  const handleTypeChange = (e) => {
    const nextType = e.target.value;
    const defaultVal = getDefaultValueForType(nextType);
    onUpdate(node.id, (prev) => ({
      ...prev,
      type: nextType,
      dvalue: defaultVal,
      value: defaultVal,
      children: nextType === 'object' || nextType === 'array' ? prev.children || [] : undefined,
    }));
  };

  const handleValueChange = (field, val) => {
    onUpdate(node.id, (prev) => ({ ...prev, [field]: val }));
  };

  // Custom metadata handlers
  const handleToggleMetaPanel = () => {
    onUpdate(node.id, (prev) => ({ ...prev, showMetaSettings: !prev.showMetaSettings }));
  };

  const handleAddMetaItem = () => {
    const newMeta = { id: Math.random().toString(36).substring(2, 9), key: '', value: '' };
    onUpdate(node.id, (prev) => ({ ...prev, customMeta: [...prev.customMeta, newMeta] }));
  };

  const handleUpdateMetaItem = (metaId, metaField, metaVal) => {
    onUpdate(node.id, (prev) => ({
      ...prev,
      customMeta: prev.customMeta.map((item) => {
        if (item.id === metaId) {
          if (metaField === 'key' && !ALPHANUMERIC_REGEX.test(metaVal)) return item;
          return { ...item, [metaField]: metaVal };
        }
        return item;
      }),
    }));
  };

  const handleDeleteMetaItem = (metaId) => {
    onUpdate(node.id, (prev) => ({
      ...prev,
      customMeta: prev.customMeta.filter((item) => item.id !== metaId),
    }));
  };

  // Drag handlers
  const handleDragStart = (e) => {
    e.dataTransfer.setData('text/plain', node.id);
    e.dataTransfer.effectAllowed = 'move';
    setIsDragging(true);
    setDraggedParentType(parentType);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
    setDragOverPosition(null);
    setDraggedParentType(null);
  };

  const handleDragOver = (e) => {
    e.preventDefault();

    if (!isDropAllowed) {
      e.dataTransfer.dropEffect = 'none';
      return;
    }

    e.dataTransfer.dropEffect = 'move';
    const rect = e.currentTarget.getBoundingClientRect();
    const relativeY = e.clientY - rect.top;

    if (isObjectOrArray) {
      if (relativeY < rect.height * 0.25) {
        setDragOverPosition('before');
      } else if (relativeY > rect.height * 0.75) {
        setDragOverPosition('after');
      } else {
        setDragOverPosition('inside');
      }
    } else {
      if (relativeY < rect.height / 2) {
        setDragOverPosition('before');
      } else {
        setDragOverPosition('after');
      }
    }
  };

  const handleDragLeave = () => {
    setDragOverPosition(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const dropAction = dragOverPosition;
    setDragOverPosition(null);

    if (!isDropAllowed) return;

    const draggedId = e.dataTransfer.getData('text/plain');
    if (draggedId === node.id) return;

    if (dropAction === 'inside' && isObjectOrArray) {
      onReparent(draggedId, node.id);
    } else {
      const offset = dropAction === 'after' ? 1 : 0;
      const targetIndex = index + offset;
      onReorder(draggedId, parentId, targetIndex);
    }
  };

  if (query && !isMatchInBranch) {
    return null;
  }

  // Row visual state styling
  const getRowContainerStyle = () => {
    let baseBorderColor = hasError ? '#ef4444' : isDirectMatch ? '#3b82f6' : '#e2e8f0';
    let baseBgColor = hasError ? '#fef2f2' : isDirectMatch ? '#eff6ff' : '#ffffff';

    if (isDragging) {
      return {
        ...rowStyle,
        border: '2px dashed #94a3b8',
        backgroundColor: '#f8fafc',
        opacity: 0.4,
        transform: 'scale(0.98)',
      };
    }

    if (dragOverPosition === 'inside' && isObjectOrArray) {
      return {
        ...rowStyle,
        borderColor: '#10b981',
        backgroundColor: '#ecfdf5',
        boxShadow: '0 0 0 2px #10b981',
        transform: 'scale(1.01)',
      };
    }

    return {
      ...rowStyle,
      borderColor: baseBorderColor,
      backgroundColor: baseBgColor,
      boxShadow: isDirectMatch ? '0 0 0 2px #3b82f6' : 'none',
      opacity: query && !isDirectMatch ? 0.6 : 1,
      cursor: draggedParentType && !isDropAllowed ? 'no-drop' : 'grab',
    };
  };

  return (
    <div style={{ marginLeft: `${depth * 20}px`, marginTop: '8px', transition: 'all 0.2s ease' }}>
      {dragOverPosition === 'before' && isDropAllowed && <div style={dropIndicatorStyle} />}

      <div
        draggable="true"
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        style={getRowContainerStyle()}
      >
        {/* Grab Handle */}
        <span style={dragHandleStyle} title="Drag to reorder or nest">
          ⣿
        </span>

        {/* Expansion Toggle */}
        {isObjectOrArray && (
          <button
            type="button"
            style={iconButtonStyle}
            onClick={() => onUpdate(node.id, (prev) => ({ ...prev, isExpanded: !prev.isExpanded }))}
          >
            {node.isExpanded ? '▼' : '▶'}
          </button>
        )}

        {/* Key / Index Badge */}
        {isParentArray ? (
          <span style={arrayBadgeStyle}>[{index}]</span>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', position: 'relative' }}>
            <input
              type="text"
              placeholder="keyName"
              value={node.key}
              onChange={handleKeyChange}
              style={{
                ...inputStyle,
                width: '120px',
                borderColor: hasError ? '#ef4444' : '#cbd5e1',
                fontWeight: isDirectMatch && node.key.toLowerCase().includes(query) ? 'bold' : 'normal',
              }}
            />
            {hasEmptyError && <span style={errorBadgeStyle}>⚠️ Key required</span>}
            {hasDuplicateError && !hasEmptyError && <span style={errorBadgeStyle}>⚠️ Duplicate</span>}
          </div>
        )}

        {/* Type Selector */}
        <select value={node.type} onChange={handleTypeChange} style={selectStyle}>
          {DATA_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>

        {/* Required Checkbox */}
        <label style={checkboxLabelStyle} title="Required field">
          <input
            type="checkbox"
            checked={Boolean(node.required)}
            onChange={(e) => onUpdate(node.id, (prev) => ({ ...prev, required: e.target.checked }))}
            style={{ cursor: 'pointer' }}
          />
          <span style={{ fontSize: '11px', fontWeight: 600, color: '#475569' }}>req</span>
        </label>

        {/* Dynamic Inputs (dvalue & value) */}
        <div style={{ display: 'flex', gap: '8px', flex: 1, minWidth: '220px' }}>
          {!isObjectOrArray && (
            <div style={{ flex: 1 }}>
              {node.type === 'boolean' ? (
                <select
                  value={String(node.dvalue)}
                  onChange={(e) => handleValueChange('dvalue', e.target.value === 'true')}
                  style={{ ...selectStyle, width: '100%' }}
                >
                  <option value="true">def: true</option>
                  <option value="false">def: false</option>
                </select>
              ) : (
                <input
                  type={node.type === 'number' ? 'number' : 'text'}
                  value={node.dvalue ?? ''}
                  placeholder="default"
                  onChange={(e) =>
                    handleValueChange(
                      'dvalue',
                      node.type === 'number' ? Number(e.target.value) : e.target.value
                    )
                  }
                  style={{ ...inputStyle, width: '100%', backgroundColor: '#fdfcf9' }}
                />
              )}
            </div>
          )}

          <div style={{ flex: 1.2 }}>
            {node.type === 'string' && (
              <input
                type="text"
                value={node.value ?? ''}
                placeholder="Current value"
                onChange={(e) => handleValueChange('value', e.target.value)}
                style={{ ...inputStyle, width: '100%' }}
              />
            )}

            {node.type === 'number' && (
              <input
                type="number"
                value={node.value ?? 0}
                placeholder="Current value"
                onChange={(e) => handleValueChange('value', Number(e.target.value))}
                style={{ ...inputStyle, width: '100%' }}
              />
            )}

            {node.type === 'boolean' && (
              <select
                value={String(node.value)}
                onChange={(e) => handleValueChange('value', e.target.value === 'true')}
                style={{ ...selectStyle, width: '100%' }}
              >
                <option value="true">val: true</option>
                <option value="false">val: false</option>
              </select>
            )}

            {(node.type === 'function' || node.type === 'jsx') && (
              <textarea
                rows={2}
                value={node.value ?? ''}
                placeholder={`Enter raw ${node.type} code...`}
                onChange={(e) => handleValueChange('value', e.target.value)}
                style={codeTextAreaStyle}
              />
            )}

            {isObjectOrArray && (
              <span style={{ fontSize: '12px', color: '#64748b', lineHeight: '30px' }}>
                ({node.children?.length || 0} {node.type === 'array' ? 'items' : 'props'})
              </span>
            )}
          </div>
        </div>

        {/* Custom Meta Panel Toggle */}
        <button
          type="button"
          onClick={handleToggleMetaPanel}
          style={{
            ...actionButtonStyle,
            backgroundColor: node.showMetaSettings ? '#dbeafe' : '#f8fafc',
            borderColor: node.showMetaSettings ? '#3b82f6' : '#cbd5e1',
          }}
          title="Configure custom attributes"
        >
          ⚙️ Meta
        </button>

        {/* Add Child Button */}
        {isObjectOrArray && (
          <button
            type="button"
            onClick={() => onAddChild(node.id, createDefaultNode('', 'string'))}
            style={actionButtonStyle}
            title={node.type === 'array' ? 'Add Item' : 'Add Property'}
          >
            + Add
          </button>
        )}

        {/* Delete Row Button */}
        <button
          type="button"
          onClick={() => onDelete(node.id)}
          style={{ ...actionButtonStyle, color: '#ef4444' }}
          title="Delete field"
        >
          ✕
        </button>
      </div>

      {dragOverPosition === 'after' && isDropAllowed && <div style={dropIndicatorStyle} />}

      {/* Expandable Custom Meta Panel */}
      {node.showMetaSettings && (
        <div style={customMetaPanelStyle}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#1e3a8a' }}>Custom Attributes</span>
            <button type="button" onClick={handleAddMetaItem} style={metaAddButtonStyle}>
              + Add Attribute
            </button>
          </div>

          {node.customMeta.length === 0 ? (
            <span style={{ fontSize: '11px', color: '#94a3b8' }}>No custom attributes.</span>
          ) : (
            node.customMeta.map((meta) => {
              const metaKeyEmpty = !meta.key.trim();
              return (
                <div key={meta.id} style={{ display: 'flex', gap: '8px', marginTop: '6px', alignItems: 'center' }}>
                  <input
                    type="text"
                    placeholder="key (alphanumeric)"
                    value={meta.key}
                    onChange={(e) => handleUpdateMetaItem(meta.id, 'key', e.target.value)}
                    style={{ ...inputStyle, flex: 1, borderColor: metaKeyEmpty ? '#ef4444' : '#cbd5e1' }}
                  />
                  <input
                    type="text"
                    placeholder="value"
                    value={meta.value}
                    onChange={(e) => handleUpdateMetaItem(meta.id, 'value', e.target.value)}
                    style={{ ...inputStyle, flex: 1.5 }}
                  />
                  <button
                    type="button"
                    onClick={() => handleDeleteMetaItem(meta.id)}
                    style={{ ...actionButtonStyle, color: '#ef4444', border: 'none', background: 'transparent' }}
                  >
                    ✕
                  </button>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Recursive Children Branches */}
      {isObjectOrArray && node.isExpanded && node.children && (
        <div style={{ borderLeft: '2px solid #e2e8f0', marginLeft: '8px' }}>
          {node.children.map((child, idx) => (
            <SchemaNodeRow
              key={child.id}
              node={child}
              depth={depth + 1}
              parentType={node.type}
              index={idx}
              parentId={node.id}
              onUpdate={onUpdate}
              onDelete={onDelete}
              onAddChild={onAddChild}
              entireTree={entireTree}
              isSiblingKeyDuplicateFn={isSiblingKeyDuplicateFn}
              onReorder={onReorder}
              onReparent={onReparent}
              draggedParentType={draggedParentType}
              setDraggedParentType={setDraggedParentType}
              searchQuery={searchQuery}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// Styling definitions
const dragHandleStyle = {
  cursor: 'grab',
  paddingRight: '6px',
  userSelect: 'none',
  fontSize: '15px',
  color: '#94a3b8',
};

const dropIndicatorStyle = {
  height: '4px',
  backgroundColor: '#3b82f6',
  borderRadius: '4px',
  margin: '6px 0',
  animation: 'pulseGlow 1.5s infinite ease-in-out',
};

const rowStyle = {
  display: 'flex',
  alignItems: 'center',
  gap: '8px',
  padding: '6px 10px',
  borderRadius: '6px',
  border: '1px solid #e2e8f0',
  transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
};

const inputStyle = {
  padding: '6px 8px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  fontSize: '12px',
  fontFamily: 'monospace',
  boxSizing: 'border-box',
};

const selectStyle = {
  padding: '6px 8px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  fontSize: '12px',
  backgroundColor: '#f8fafc',
  boxSizing: 'border-box',
};

const checkboxLabelStyle = {
  display: 'flex',
  alignItems: 'center',
  gap: '4px',
  padding: '4px 6px',
  background: '#f1f5f9',
  borderRadius: '4px',
  cursor: 'pointer',
  userSelect: 'none',
};

const codeTextAreaStyle = {
  width: '100%',
  fontFamily: 'monospace',
  fontSize: '11px',
  padding: '4px 6px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  backgroundColor: '#f8fafc',
  resize: 'vertical',
  boxSizing: 'border-box',
};

const arrayBadgeStyle = {
  fontSize: '12px',
  fontWeight: 'bold',
  color: '#475569',
  padding: '4px 8px',
  background: '#f1f5f9',
  borderRadius: '4px',
};

const iconButtonStyle = {
  border: 'none',
  background: 'transparent',
  cursor: 'pointer',
  fontSize: '12px',
  padding: '2px 6px',
};

const actionButtonStyle = {
  padding: '4px 8px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  background: '#f8fafc',
  cursor: 'pointer',
  fontSize: '12px',
  fontWeight: 500,
};

const customMetaPanelStyle = {
  background: '#eff6ff',
  padding: '10px 12px',
  borderRadius: '0 0 6px 6px',
  border: '1px solid #bfdbfe',
  borderTop: 'none',
  marginLeft: '12px',
};

const metaAddButtonStyle = {
  background: '#2563eb',
  color: '#ffffff',
  border: 'none',
  borderRadius: '4px',
  fontSize: '10px',
  fontWeight: 'bold',
  padding: '4px 8px',
  cursor: 'pointer',
};

const errorBadgeStyle = {
  position: 'absolute',
  top: '-18px',
  left: '2px',
  color: '#ef4444',
  fontSize: '10px',
  fontWeight: 'bold',
  whiteSpace: 'nowrap',
};

if (typeof document !== 'undefined') {
  const styleSheet = document.createElement('style');
  styleSheet.type = 'text/css';
  styleSheet.innerText = `
    @keyframes pulseGlow {
      0% { box-shadow: 0 0 0 0px rgba(59, 130, 246, 0.4); opacity: 0.8; }
      50% { box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.2); opacity: 1; }
      100% { box-shadow: 0 0 0 0px rgba(59, 130, 246, 0.4); opacity: 0.8; }
    }
  `;
  document.head.appendChild(styleSheet);
}
