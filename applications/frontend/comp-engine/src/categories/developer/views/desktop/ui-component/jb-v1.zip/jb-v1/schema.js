import helpers from 'ui-helpers';

export const getDefaultValueForType = (type) => {
  switch (type) {
    case 'string':
      return '';
    case 'number':
      return 0;
    case 'boolean':
      return false;
    case 'function':
      return '() => {\n  return null;\n}';
    case 'jsx':
      return '<div className="custom-node">\n  <span>Rendered Item</span>\n</div>';
    case 'object':
    case 'array':
    default:
      return undefined;
  }
};


export const createDefaultNode = (key = '', type = 'string', overrides = {}) => {
  const initialDefault = getDefaultValueForType(type);
  return {
    id:(`r${helpers.random.number()}`),
    key:key,
    type:type,
    required:false,
    dvalue:initialDefault,
    value:initialDefault,
    isNull:false,
    customMeta: [], // Array of { id, key, value }
    children:type === 'object' || type === 'array' ? [] : undefined,
    isExpanded:true,
    showMetaSettings:false,
    ...overrides,
  };
};
  