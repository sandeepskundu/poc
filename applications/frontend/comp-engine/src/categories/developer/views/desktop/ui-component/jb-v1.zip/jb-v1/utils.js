const data = {
    types:['string', 'number', 'boolean', 'object', 'array', 'function', 'jsx', 'sandeep', 'mandeep']
}

export default {
    data:data
}