// src/components/JsonSchemaBuilder.jsx
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { SchemaNodeRow } from './SchemaNodeRow';
import {
  createDefaultNode,
  updateNode,
  deleteNode,
  addChildNode,
  isSiblingKeyDuplicate,
  isTreeValid,
  serializeSchemaDefinition,
  serializeEvaluatedData,
  extractNode,
  insertNodeAtActiveLevel,
  reparentNode,
  expandMatchingNodes,
} from './schemaTree';
import {
  createVersionSnapshot,
  saveVersionsToStorage,
  loadVersionsFromStorage,
} from './schemaVersioning';

const STORAGE_KEY = 'SCHEMA_VERSION_HISTORY';

export const JsonSchemaBuilder = ({
  initialNodes,
  onChange,
  renderCustomMetaAttribute,
  getTypeIcon,
}) => {
  const [outputMode, setOutputMode] = useState('definition'); // 'definition' | 'evaluated'

  const defaultTree = useMemo(() => [
    createDefaultNode('userId', 'number', { required: true, dvalue: 1001, value: 1001 }),
    {
      ...createDefaultNode('userConfig', 'object', { required: true }),
      children: [
        createDefaultNode('theme_mode', 'string', { required: false, dvalue: 'dark', value: 'dark' }),
      ],
    },
  ], []);

  const [history, setHistory] = useState([defaultTree]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const tree = history[historyIndex] || [];

  const [versions, setVersions] = useState(() => loadVersionsFromStorage(STORAGE_KEY));
  const [showVersionModal, setShowVersionModal] = useState(false);
  const [newVersionTag, setNewVersionTag] = useState('');
  const [newVersionDesc, setNewVersionDesc] = useState('');

  const [searchQuery, setSearchQuery] = useState('');
  const [draggedParentType, setDraggedParentType] = useState(null);

  const commitTreeChange = useCallback((newTree) => {
    setHistory((prevHistory) => {
      const updatedHistory = prevHistory.slice(0, historyIndex + 1);
      return [...updatedHistory, newTree];
    });
    setHistoryIndex((prevIndex) => prevIndex + 1);
  }, [historyIndex]);

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) setHistoryIndex((prev) => prev - 1);
  }, [historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) setHistoryIndex((prev) => prev + 1);
  }, [historyIndex, history.length]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        if (e.shiftKey) handleRedo();
        else handleUndo();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
        handleRedo();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);

  useEffect(() => {
    saveVersionsToStorage(STORAGE_KEY, versions);
  }, [versions]);

  const handleSearchChange = (e) => {
    const q = e.target.value;
    setSearchQuery(q);
    if (q.trim()) {
      commitTreeChange(expandMatchingNodes(tree, q));
    }
  };

  const isValid = useMemo(() => isTreeValid(tree), [tree]);

  const serializedOutput = useMemo(() => {
    if (!isValid || !tree) return null;

    let res;
    if (outputMode === 'definition') {
      res = serializeSchemaDefinition(tree, 'object');
    } else {
      res = serializeEvaluatedData(tree, 'object');
    }

    if (onChange) onChange(res, tree);
    return res;
  }, [tree, isValid, outputMode, onChange]);

  const handleUpdate = (id, updater) => {
    commitTreeChange(updateNode(tree, id, updater));
  };

  const handleDelete = (id) => {
    commitTreeChange(deleteNode(tree, id));
  };

  const handleAddChild = (parentId, child) => {
    commitTreeChange(addChildNode(tree, parentId, child));
  };

  const handleAddRootField = () => {
    commitTreeChange([...tree, createDefaultNode('', 'string')]);
  };

  const handleReorder = (draggedId, targetParentId, targetIndex) => {
    const { cleanedTree, draggedNode } = extractNode(tree, draggedId);
    if (!draggedNode) return;
    const reorderedTree = insertNodeAtActiveLevel(cleanedTree, targetParentId, draggedNode, targetIndex);
    commitTreeChange(reorderedTree);
  };

  const handleReparent = (draggedId, targetParentId) => {
    commitTreeChange(reparentNode(tree, draggedId, targetParentId));
  };

  const handleSaveVersion = (e) => {
    e.preventDefault();
    if (!newVersionTag.trim()) return;
    const snapshot = createVersionSnapshot(tree, newVersionTag.trim(), newVersionDesc.trim());
    setVersions((prev) => [snapshot, ...prev]);
    setNewVersionTag('');
    setNewVersionDesc('');
  };

  const handleRestoreVersion = (snapshot) => {
    if (window.confirm(`Restore schema to checkpoint "${snapshot.versionTag}"?`)) {
      commitTreeChange(JSON.parse(JSON.stringify(snapshot.tree)));
      setShowVersionModal(false);
    }
  };

  const handleDeleteVersion = (snapshotId) => {
    setVersions((prev) => prev.filter((v) => v.id !== snapshotId));
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: '24px', padding: '20px' }}>
      {/* Editor Panel Column */}
      <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
        <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', alignItems: 'center' }}>
          <div style={{ flex: 1, position: 'relative' }}>
            <input
              type="text"
              placeholder="🔍 Search schema..."
              value={searchQuery}
              onChange={handleSearchChange}
              style={searchBarInputStyle}
            />
            {searchQuery && (
              <button type="button" onClick={() => setSearchQuery('')} style={searchClearButtonStyle}>
                ✕
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={handleUndo}
            disabled={historyIndex === 0}
            style={{ ...historyButtonStyle, opacity: historyIndex === 0 ? 0.4 : 1 }}
          >
            ↶ Undo
          </button>

          <button
            type="button"
            onClick={handleRedo}
            disabled={historyIndex >= history.length - 1}
            style={{ ...historyButtonStyle, opacity: historyIndex >= history.length - 1 ? 0.4 : 1 }}
          >
            ↷ Redo
          </button>

          <button
            type="button"
            onClick={() => setShowVersionModal(true)}
            style={{ ...historyButtonStyle, backgroundColor: '#3b82f6', color: '#ffffff' }}
          >
            🔖 Versions ({versions.length})
          </button>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div>
            <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 600 }}>Schema Field Editor</h3>
            {!isValid && (
              <span style={{ fontSize: '11px', color: '#ef4444', fontWeight: 'bold' }}>
                ⚠️ Resolve empty or duplicate keys before compiling
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={handleAddRootField}
            style={{
              padding: '6px 12px',
              backgroundColor: '#2563eb',
              color: '#ffffff',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontWeight: 500,
            }}
          >
            + Add Root Field
          </button>
        </div>

        {(tree || []).map((node, index) => (
          <SchemaNodeRow
            key={node.id}
            node={node}
            depth={0}
            parentType="object"
            index={index}
            parentId="root"
            onUpdate={handleUpdate}
            onDelete={handleDelete}
            onAddChild={handleAddChild}
            entireTree={tree}
            isSiblingKeyDuplicateFn={isSiblingKeyDuplicate}
            onReorder={handleReorder}
            onReparent={handleReparent}
            draggedParentType={draggedParentType}
            setDraggedParentType={setDraggedParentType}
            searchQuery={searchQuery}
            renderCustomMetaAttribute={renderCustomMetaAttribute}
            getTypeIcon={getTypeIcon}
          />
        ))}
      </div>

      {/* Output Panel Column */}
      <div style={{ background: '#0f172a', padding: '16px', borderRadius: '8px', color: '#f8fafc' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div style={{ display: 'flex', background: '#1e293b', borderRadius: '6px', padding: '2px' }}>
            <button
              type="button"
              onClick={() => setOutputMode('definition')}
              style={{
                ...tabButtonStyle,
                background: outputMode === 'definition' ? '#3b82f6' : 'transparent',
              }}
            >
              Schema Definition
            </button>
            <button
              type="button"
              onClick={() => setOutputMode('evaluated')}
              style={{
                ...tabButtonStyle,
                background: outputMode === 'evaluated' ? '#3b82f6' : 'transparent',
              }}
            >
              Evaluated JSON Data
            </button>
          </div>

          <span
            style={{
              fontSize: '11px',
              padding: '2px 8px',
              borderRadius: '10px',
              background: isValid ? '#1e293b' : '#7f1d1d',
              color: isValid ? '#10b981' : '#f87171',
              fontWeight: 'bold',
            }}
          >
            {isValid ? '● Live' : '● Paused'}
          </span>
        </div>

        {isValid ? (
          <pre style={codeOutputStyle}>
            {JSON.stringify(serializedOutput, null, 2)}
          </pre>
        ) : (
          <div style={errorContainerStyle}>
            ❌ Compilation Paused. Provide unique keys.
          </div>
        )}
      </div>

      {/* Version History Checkpoint Modal */}
      {showVersionModal && (
        <div style={modalBackdropStyle}>
          <div style={modalContentStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ margin: 0, fontSize: '18px', color: '#0f172a' }}>Schema Version Checkpoints</h3>
              <button
                type="button"
                onClick={() => setShowVersionModal(false)}
                style={{ border: 'none', background: 'transparent', fontSize: '18px', cursor: 'pointer' }}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveVersion} style={versionFormStyle}>
              <h4 style={{ margin: '0 0 8px 0', fontSize: '13px', color: '#334155' }}>Save Named Checkpoint</h4>
              <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
                <input
                  type="text"
                  placeholder="Version Tag (e.g. v1.0.0)"
                  value={newVersionTag}
                  onChange={(e) => setNewVersionTag(e.target.value)}
                  style={{ ...inputStyle, width: '150px' }}
                  required
                />
                <input
                  type="text"
                  placeholder="Description of changes"
                  value={newVersionDesc}
                  onChange={(e) => setNewVersionDesc(e.target.value)}
                  style={{ ...inputStyle, flex: 1 }}
                />
                <button
                  type="submit"
                  style={{
                    padding: '6px 12px',
                    backgroundColor: '#10b981',
                    color: '#ffffff',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontWeight: 600,
                  }}
                >
                  Save Checkpoint
                </button>
              </div>
            </form>

            <div style={{ maxHeight: '350px', overflowY: 'auto' }}>
              {versions.length === 0 ? (
                <p style={{ textAlign: 'center', color: '#94a3b8', fontSize: '13px', margin: '24px 0' }}>
                  No saved version checkpoints yet.
                </p>
              ) : (
                versions.map((ver) => (
                  <div key={ver.id} style={versionItemStyle}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={versionTagBadgeStyle}>{ver.versionTag}</span>
                        <span style={{ fontSize: '11px', color: '#64748b' }}>
                          {new Date(ver.timestamp).toLocaleString()}
                        </span>
                      </div>
                      {ver.description && (
                        <p style={{ margin: '4px 0 0 0', fontSize: '12px', color: '#475569' }}>
                          {ver.description}
                        </p>
                      )}
                    </div>

                    <div style={{ display: 'flex', gap: '8px' }}>
                      <button
                        type="button"
                        onClick={() => handleRestoreVersion(ver)}
                        style={restoreButtonStyle}
                      >
                        Restore
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteVersion(ver.id)}
                        style={deleteSnapshotButtonStyle}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const tabButtonStyle = {
  padding: '6px 12px',
  borderRadius: '4px',
  border: 'none',
  cursor: 'pointer',
  fontSize: '12px',
  fontWeight: 600,
  transition: 'all 0.15s ease',
  color: '#ffffff',
};

const searchBarInputStyle = {
  width: '100%',
  padding: '8px 12px',
  borderRadius: '6px',
  border: '1px solid #cbd5e1',
  fontSize: '13px',
  outline: 'none',
  boxSizing: 'border-box',
};

const searchClearButtonStyle = {
  position: 'absolute',
  right: '10px',
  top: '50%',
  transform: 'translateY(-50%)',
  border: 'none',
  background: 'transparent',
  color: '#94a3b8',
  cursor: 'pointer',
  fontSize: '13px',
};

const historyButtonStyle = {
  padding: '6px 12px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  background: '#ffffff',
  fontSize: '12px',
  fontWeight: 600,
  cursor: 'pointer',
  color: '#1e293b',
};

const codeOutputStyle = {
  margin: 0,
  fontSize: '12px',
  fontFamily: 'monospace',
  maxHeight: '650px',
  overflowY: 'auto',
  lineHeight: '1.5',
};

const errorContainerStyle = {
  padding: '20px',
  background: '#1e293b',
  borderRadius: '6px',
  color: '#94a3b8',
  fontSize: '13px',
  textAlign: 'center',
  marginTop: '20px',
};

const modalBackdropStyle = {
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: 'rgba(15, 23, 42, 0.6)',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 1000,
};

const modalContentStyle = {
  background: '#ffffff',
  padding: '24px',
  borderRadius: '8px',
  width: '600px',
  maxWidth: '90%',
  boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)',
};

const versionFormStyle = {
  background: '#f8fafc',
  padding: '12px',
  borderRadius: '6px',
  border: '1px solid #e2e8f0',
  marginBottom: '16px',
};

const inputStyle = {
  padding: '6px 10px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  fontSize: '12px',
};

const versionItemStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '10px 12px',
  borderRadius: '6px',
  border: '1px solid #e2e8f0',
  marginBottom: '8px',
  background: '#ffffff',
};

const versionTagBadgeStyle = {
  fontWeight: 'bold',
  fontSize: '12px',
  backgroundColor: '#eff6ff',
  color: '#2563eb',
  padding: '2px 8px',
  borderRadius: '4px',
  border: '1px solid #bfdbfe',
};

const restoreButtonStyle = {
  padding: '4px 10px',
  backgroundColor: '#2563eb',
  color: '#ffffff',
  border: 'none',
  borderRadius: '4px',
  fontSize: '11px',
  fontWeight: 600,
  cursor: 'pointer',
};

const deleteSnapshotButtonStyle = {
  padding: '4px 8px',
  backgroundColor: 'transparent',
  color: '#ef4444',
  border: '1px solid #fca5a5',
  borderRadius: '4px',
  fontSize: '11px',
  cursor: 'pointer',
};