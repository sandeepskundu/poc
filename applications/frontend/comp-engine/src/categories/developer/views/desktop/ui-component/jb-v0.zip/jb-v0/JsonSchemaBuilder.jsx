// src/components/JsonSchemaBuilder.jsx
import React, { useState, useMemo } from 'react';
import { SchemaNodeRow } from './SchemaNodeRow';
import {
  createDefaultNode,
  updateNode,
  deleteNode,
  addChildNode,
  serializeSchemaDefinition,
  isSiblingKeyDuplicate,
  isTreeValid,
  extractNode,
  insertNodeAtActiveLevel,
  reparentNode,
  expandMatchingNodes,
} from './schemaTree';

export const JsonSchemaBuilder = ({ initialNodes, onChange }) => {
  const [tree, setTree] = useState(
    initialNodes || [
      createDefaultNode('userId', 'number', {
        required: true,
        dvalue: 1001,
        value: 1001,
        customMeta: [
          { id: 'm1', key: 'description', value: 'Unique identifier for users' },
          { id: 'm2', key: 'minimum', value: '1000' },
        ],
      }),
      {
        ...createDefaultNode('userConfig', 'object', { required: true }),
        children: [
          createDefaultNode('theme', 'string', {
            required: false,
            dvalue: 'dark',
            value: 'dark',
            customMeta: [{ id: 'm3', key: 'enum', value: '["dark", "light"]' }],
          }),
          createDefaultNode('renderProfileCard', 'jsx'),
          createDefaultNode('validateSession', 'function'),
        ],
      },
      createDefaultNode('roles', 'array', { required: false }),
    ]
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [draggedParentType, setDraggedParentType] = useState(null);

  // Search input handler
  const handleSearchChange = (e) => {
    const q = e.target.value;
    setSearchQuery(q);
    if (q.trim()) {
      setTree((prev) => expandMatchingNodes(prev, q));
    }
  };

  const isValid = useMemo(() => isTreeValid(tree, 'object'), [tree]);

  const serializedSchema = useMemo(() => {
    if (!isValid) return null;
    const res = serializeSchemaDefinition(tree, 'object');
    if (onChange) onChange(res, tree);
    return res;
  }, [tree, isValid, onChange]);

  const handleUpdate = (id, updater) => {
    setTree((prev) => updateNode(prev, id, updater));
  };

  const handleDelete = (id) => {
    setTree((prev) => deleteNode(prev, id));
  };

  const handleAddChild = (parentId, child) => {
    setTree((prev) => addChildNode(prev, parentId, child));
  };

  const handleAddRootField = () => {
    setTree((prev) => [...prev, createDefaultNode('', 'string')]);
  };

  const handleReorder = (draggedId, targetParentId, targetIndex) => {
    const { cleanedTree, draggedNode } = extractNode(tree, draggedId);
    if (!draggedNode) return;
    const reorderedTree = insertNodeAtActiveLevel(cleanedTree, targetParentId, draggedNode, targetIndex);
    setTree(reorderedTree);
  };

  const handleReparent = (draggedId, targetParentId) => {
    const reparentedTree = reparentNode(tree, draggedId, targetParentId);
    setTree(reparentedTree);
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: '24px', padding: '20px' }}>
      {/* Visual Editor Column */}
      <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
        {/* Global Search Bar */}
        <div style={{ marginBottom: '16px', position: 'relative' }}>
          <input
            type="text"
            placeholder="🔍 Search key, type, value, or custom metadata attribute..."
            value={searchQuery}
            onChange={handleSearchChange}
            style={searchBarInputStyle}
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              style={searchClearButtonStyle}
            >
              ✕
            </button>
          )}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div>
            <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 600 }}>Schema Field Editor</h3>
            {!isValid && (
              <span style={{ fontSize: '11px', color: '#ef4444', fontWeight: 'bold' }}>
                ⚠️ Resolve empty or duplicate keys before compiling
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={handleAddRootField}
            style={{
              padding: '6px 12px',
              backgroundColor: '#2563eb',
              color: '#ffffff',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontWeight: 500,
            }}
          >
            + Add Root Field
          </button>
        </div>

        {tree.map((node, index) => (
          <SchemaNodeRow
            key={node.id}
            node={node}
            depth={0}
            parentType="object"
            index={index}
            parentId="root"
            onUpdate={handleUpdate}
            onDelete={handleDelete}
            onAddChild={handleAddChild}
            entireTree={tree}
            isSiblingKeyDuplicateFn={isSiblingKeyDuplicate}
            onReorder={handleReorder}
            onReparent={handleReparent}
            draggedParentType={draggedParentType}
            setDraggedParentType={setDraggedParentType}
            searchQuery={searchQuery}
          />
        ))}
      </div>

      {/* Live Output Column */}
      <div style={{ background: '#0f172a', padding: '16px', borderRadius: '8px', color: '#f8fafc' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
          <h3 style={{ margin: 0, fontSize: '14px', color: '#94a3b8' }}>Schema Definition Output</h3>
          <span
            style={{
              fontSize: '11px',
              padding: '2px 8px',
              borderRadius: '10px',
              background: isValid ? '#1e293b' : '#7f1d1d',
              color: isValid ? '#10b981' : '#f87171',
              fontWeight: 'bold',
            }}
          >
            {isValid ? '● Valid Schema' : '● Compilation Paused'}
          </span>
        </div>

        {isValid ? (
          <pre
            style={{
              margin: 0,
              fontSize: '12px',
              fontFamily: 'monospace',
              maxHeight: '650px',
              overflowY: 'auto',
              lineHeight: '1.5',
            }}
          >
            {JSON.stringify(serializedSchema, null, 2)}
          </pre>
        ) : (
          <div
            style={{
              padding: '20px',
              background: '#1e293b',
              borderRadius: '6px',
              color: '#94a3b8',
              fontSize: '13px',
              textAlign: 'center',
              marginTop: '20px',
            }}
          >
            ❌ Compilation Paused. Please provide unique alphanumeric names for all keys and custom metadata names.
          </div>
        )}
      </div>
    </div>
  );
};

const searchBarInputStyle = {
  width: '100%',
  padding: '10px 14px',
  borderRadius: '6px',
  border: '1px solid #cbd5e1',
  fontSize: '13px',
  outline: 'none',
  boxSizing: 'border-box',
};

const searchClearButtonStyle = {
  position: 'absolute',
  right: '12px',
  top: '50%',
  transform: 'translateY(-50%)',
  border: 'none',
  background: 'transparent',
  color: '#94a3b8',
  cursor: 'pointer',
  fontSize: '14px',
};
