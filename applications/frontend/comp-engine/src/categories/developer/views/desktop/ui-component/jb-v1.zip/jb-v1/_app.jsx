// src/App.jsx
import React from 'react';
import { JsonSchemaBuilder } from './JsonSchemaBuilder';

export default function App() {
  const handleSchemaChange = (serializedDefinition, rawAstTree) => {
    console.log('Updated Schema Definition:', serializedDefinition);
  };

  /**
   * Custom Template Renderer for Meta Panel Attributes:
   * Provides custom React components based on the attribute's key name!
   */
  const customMetaRenderer = ({ meta, node, onChangeValue }) => {

    console.log(meta, node)
    const keyLower = (meta.key || '').toLowerCase();

    // 1. Color Picker for keys containing 'color'
    if (keyLower.includes('color')) {
      return (
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <input
            type="color"
            value={meta.value || '#000000'}
            onChange={(e) => onChangeValue(e.target.value)}
            style={{ cursor: 'pointer', border: 'none', width: '30px', height: '30px', padding: 0 }}
          />
          <span style={{ fontSize: '11px', fontFamily: 'monospace', color: '#475569' }}>
            {meta.value || '#000000'}
          </span>
        </div>
      );
    }

    // 2. Select Dropdown for 'enum'
    if (keyLower === 'enum') {
      return (
        <select
          value={meta.value}
          onChange={(e) => onChangeValue(e.target.value)}
          style={{
            padding: '6px 8px',
            borderRadius: '4px',
            border: '1px solid #cbd5e1',
            fontSize: '12px',
            width: '100%',
            background: '#ffffff',
          }}
        >
          <option value="dark">dark</option>
          <option value="light">light</option>
          <option value="system">system</option>
        </select>
      );
    }

    // 3. Multiline Textarea for 'description' or 'helptext'
    if (keyLower.includes('desc') || keyLower.includes('help')) {
      return (
        <textarea
          rows={2}
          value={meta.value}
          placeholder="Enter detailed documentation..."
          onChange={(e) => onChangeValue(e.target.value)}
          style={{
            width: '100%',
            fontFamily: 'sans-serif',
            fontSize: '11px',
            padding: '4px 6px',
            borderRadius: '4px',
            border: '1px solid #cbd5e1',
            resize: 'vertical',
            boxSizing: 'border-box',
          }}
        />
      );
    }

    // 4. Numeric input stepper for constraints
    if (['min', 'max', 'minimum', 'maximum', 'minlength', 'maxlength'].includes(keyLower)) {
      return (
        <input
          type="number"
          value={meta.value}
          placeholder="0"
          onChange={(e) => onChangeValue(Number(e.target.value))}
          style={{
            padding: '6px 8px',
            borderRadius: '4px',
            border: '1px solid #cbd5e1',
            fontSize: '12px',
            fontFamily: 'monospace',
            width: '100%',
            boxSizing: 'border-box',
          }}
        />
      );
    }

    // Returning null falls back to the default input box automatically
    return null;
  };

  return (
    <div style={{ maxWidth: '1440px', margin: '0 auto', fontFamily: 'system-ui, sans-serif' }}>
      <header style={{ padding: '20px', borderBottom: '1px solid #e2e8f0' }}>
        <h1 style={{ margin: 0, fontSize: '22px' }}>Custom Template Meta Schema Builder</h1>
        <p style={{ margin: '6px 0 0', color: '#64748b', fontSize: '14px' }}>
          Provides custom React templates (Color pickers, Enum dropdowns, Rich textareas) for custom metadata attributes inside the ⚙️ Meta panel.
        </p>
      </header>
      <main>
        <JsonSchemaBuilder
          onChange={handleSchemaChange}
          renderCustomMetaAttribute={customMetaRenderer}
        />
      </main>
    </div>
  );
}
