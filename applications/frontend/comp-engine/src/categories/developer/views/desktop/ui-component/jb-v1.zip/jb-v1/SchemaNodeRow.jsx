
import {useState} from 'react';
import {
  ALPHANUMERIC_REGEX,
  DATA_TYPES,
  createDefaultNode,
  getDefaultValueForType,
  nodeMatchesQuery,
} from './schemaTree';

const DEFAULT_TYPE_ICONS = {
  string: '🔤',
  number: '🔢',
  boolean: '🌗',
  object: '📁',
  array: '📋',
  function: '⚡',
  jsx: '⚛️',
};

export const SchemaNodeRow = ({
  node,
  depth,
  parentType,
  index,
  parentId = 'root',
  onUpdate,
  onDelete,
  onAddChild,
  entireTree,
  isSiblingKeyDuplicateFn,
  onReorder,
  onReparent,
  draggedParentType,
  setDraggedParentType,
  searchQuery,
  renderCustomMetaAttribute,
  getTypeIcon,
}) => {
  const isObjectOrArray = node.type === 'object' || node.type === 'array';
  const isParentArray = parentType === 'array';

  const [isEditing, setIsEditing] = useState(!node.key && depth === 0);
  const [dragOverPosition, setDragOverPosition] = useState(null);
  const [isDragging, setIsDragging] = useState(false);

  // Strict Array Fallbacks preventing 'map of undefined' crashes
  const safeCustomMeta = node.customMeta || [];
  const safeChildren = node.children || [];

  const query = (searchQuery || '').trim().toLowerCase();
  const isMatchInBranch = query ? nodeMatchesQuery(node, query) : true;
  const isDirectMatch = query && (
    (node.key || '').toLowerCase().includes(query) ||
    (node.type || '').toLowerCase().includes(query) ||
    String(node.value || '').toLowerCase().includes(query) ||
    (safeCustomMeta.some((meta) =>
      (meta.key || '').toLowerCase().includes(query) ||
      String(meta.value || '').toLowerCase().includes(query)
    ))
  );

  const hasDuplicateError = !isParentArray && isSiblingKeyDuplicateFn(entireTree, node.id, node.key);
  const hasEmptyError = !isParentArray && (!node.key || !node.key.trim());
  const hasError = hasDuplicateError || hasEmptyError;

  const isDropAllowed = draggedParentType === null || draggedParentType === parentType;

  const handleKeyChange = (e) => {
    const rawVal = e.target.value;
    if (ALPHANUMERIC_REGEX.test(rawVal)) {
      onUpdate(node.id, (prev) => ({ ...prev, key: rawVal }));
    }
  };

  const handleTypeChange = (e) => {
    const nextType = e.target.value;
    const defaultVal = getDefaultValueForType(nextType);
    onUpdate(node.id, (prev) => ({
      ...prev,
      type: nextType,
      dvalue: defaultVal,
      value: defaultVal,
      isNull: false,
      children: nextType === 'object' || nextType === 'array' ? prev.children || [] : undefined,
    }));
  };

  const handleValueChange = (field, val) => {
    onUpdate(node.id, (prev) => ({ ...prev, [field]: val }));
  };

  const handleToggleNull = (e) => {
    onUpdate(node.id, (prev) => ({ ...prev, isNull: e.target.checked }));
  };

  const handleAddMetaItem = () => {
    const newMeta = { id: Math.random().toString(36).substring(2, 9), key: '', value: '' };
    onUpdate(node.id, (prev) => ({
      ...prev,
      customMeta: [...safeCustomMeta, newMeta],
    }));
  };

  const handleUpdateMetaItem = (metaId, metaField, metaVal) => {
    onUpdate(node.id, (prev) => ({
      ...prev,
      customMeta: safeCustomMeta.map((item) => {
        if (item.id === metaId) {
          if (metaField === 'key' && !ALPHANUMERIC_REGEX.test(metaVal)) return item;
          return { ...item, [metaField]: metaVal };
        }
        return item;
      }),
    }));
  };

  const handleDeleteMetaItem = (metaId) => {
    onUpdate(node.id, (prev) => ({
      ...prev,
      customMeta: safeCustomMeta.filter((item) => item.id !== metaId),
    }));
  };

  const handleDragStart = (e) => {
    e.dataTransfer.setData('text/plain', node.id);
    e.dataTransfer.effectAllowed = 'move';
    setIsDragging(true);
    setDraggedParentType(parentType);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
    setDragOverPosition(null);
    setDraggedParentType(null);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    if (!isDropAllowed) {
      e.dataTransfer.dropEffect = 'none';
      return;
    }
    e.dataTransfer.dropEffect = 'move';
    const rect = e.currentTarget.getBoundingClientRect();
    const relativeY = e.clientY - rect.top;

    if (isObjectOrArray) {
      if (relativeY < rect.height * 0.25) setDragOverPosition('before');
      else if (relativeY > rect.height * 0.75) setDragOverPosition('after');
      else setDragOverPosition('inside');
    } else {
      if (relativeY < rect.height / 2) setDragOverPosition('before');
      else setDragOverPosition('after');
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const dropAction = dragOverPosition;
    setDragOverPosition(null);
    if (!isDropAllowed) return;

    const draggedId = e.dataTransfer.getData('text/plain');
    if (draggedId === node.id) return;

    if (dropAction === 'inside' && isObjectOrArray) {
      onReparent(draggedId, node.id);
    } else {
      const offset = dropAction === 'after' ? 1 : 0;
      onReorder(draggedId, parentId, index + offset);
    }
  };

  if (query && !isMatchInBranch) return null;

  const resolvedIcon = getTypeIcon ? getTypeIcon(node.type, node) : (DEFAULT_TYPE_ICONS[node.type] || '📄');

  const getRowContainerStyle = () => {
    let baseBorderColor = hasError ? '#ef4444' : isDirectMatch ? '#3b82f6' : '#e2e8f0';
    let baseBgColor = hasError ? '#fef2f2' : isDirectMatch ? '#eff6ff' : '#ffffff';

    if (isDragging) {
      return {
        ...rowStyle,
        border: '2px dashed #94a3b8',
        backgroundColor: '#f8fafc',
        opacity: 0.4,
        transform: 'scale(0.98)',
      };
    }

    if (dragOverPosition === 'inside' && isObjectOrArray) {
      return {
        ...rowStyle,
        borderColor: '#10b981',
        backgroundColor: '#ecfdf5',
        boxShadow: '0 0 0 2px #10b981',
        transform: 'scale(1.01)',
      };
    }

    return {
      ...rowStyle,
      borderColor: baseBorderColor,
      backgroundColor: baseBgColor,
      boxShadow: isDirectMatch ? '0 0 0 2px #3b82f6' : 'none',
      opacity: query && !isDirectMatch ? 0.6 : 1,
      cursor: draggedParentType && !isDropAllowed ? 'no-drop' : 'grab',
    };
  };

  return (
    <div style={{ marginLeft: `${depth * 20}px`, marginTop: '8px', transition: 'all 0.2s ease' }}>
      {dragOverPosition === 'before' && isDropAllowed && <div style={dropIndicatorStyle} />}

      {/* --- COLLAPSED SUMMARY SUMMARY --- */}
      <div
        draggable="true"
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onDragOver={handleDragOver}
        onDragLeave={() => setDragOverPosition(null)}
        onDrop={handleDrop}
        style={getRowContainerStyle()}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1, overflow: 'hidden' }}>
          <span style={dragHandleStyle}>⣿</span>

          {isObjectOrArray && (
            <button
              type="button"
              style={iconButtonStyle}
              onClick={() => onUpdate(node.id, (prev) => ({ ...prev, isExpanded: !prev.isExpanded }))}
            >
              {node.isExpanded ? '▼' : '▶'}
            </button>
          )}

          <span style={typeIconStyle} title={`Type: ${node.type}`}>
            {resolvedIcon}
          </span>

          {isParentArray ? (
            <span style={arrayBadgeStyle}>[{index}]</span>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span
                style={{
                  ...labelTextStyle,
                  color: hasError ? '#ef4444' : '#0f172a',
                  fontWeight: isDirectMatch ? 800 : 600,
                }}
              >
                {node.key || '<unnamed_key>'}
              </span>
              {hasError && (
                <span style={{ fontSize: '10px', color: '#ef4444', fontWeight: 'bold' }}>
                  {hasEmptyError ? '⚠️ (Key required)' : '⚠️ (Duplicate)'}
                </span>
              )}
            </div>
          )}

          <span style={typeBadgeStyle}>{node.type}</span>
          {node.required && <span style={reqBadgeStyle}>required</span>}
          {node.isNull && <span style={nullBadgeStyle}>val: null</span>}

          {isObjectOrArray && (
            <span style={{ fontSize: '11px', color: '#94a3b8' }}>
              ({safeChildren.length} {node.type === 'array' ? 'items' : 'props'})
            </span>
          )}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          {isObjectOrArray && (
            <button
              type="button"
              onClick={() => onAddChild(node.id, createDefaultNode('', 'string'))}
              style={{ ...actionButtonStyle, color: '#2563eb' }}
            >
              + Add
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsEditing(!isEditing)}
            style={{
              ...actionButtonStyle,
              backgroundColor: isEditing ? '#2563eb' : '#ffffff',
              color: isEditing ? '#ffffff' : '#334155',
              borderColor: isEditing ? '#2563eb' : '#cbd5e1',
            }}
          >
            {isEditing ? 'Done' : 'Edit'}
          </button>

          <button
            type="button"
            onClick={() => onDelete(node.id)}
            style={{ ...actionButtonStyle, color: '#ef4444', borderColor: '#fca5a5' }}
          >
            Delete
          </button>
        </div>
      </div>

      {dragOverPosition === 'after' && isDropAllowed && <div style={dropIndicatorStyle} />}

      {/* --- EXPANDED EDIT DRAWER --- */}
      {isEditing && (
        <div style={editDrawerStyle}>
          <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '12px', flexWrap: 'wrap' }}>
            {!isParentArray && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                <label style={fieldLabelStyle}>Key Name (alphanumeric / _)</label>
                <input
                  type="text"
                  placeholder="key_name"
                  value={node.key || ''}
                  onChange={handleKeyChange}
                  style={{
                    ...inputStyle,
                    width: '180px',
                    borderColor: hasError ? '#ef4444' : '#cbd5e1',
                  }}
                />
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <label style={fieldLabelStyle}>Data Type</label>
              <select value={node.type || 'string'} onChange={handleTypeChange} style={selectStyle}>
                {DATA_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <label style={fieldLabelStyle}>Constraints</label>
              <div style={{ display: 'flex', gap: '8px' }}>
                <label style={checkboxLabelStyle}>
                  <input
                    type="checkbox"
                    checked={Boolean(node.required)}
                    onChange={(e) => onUpdate(node.id, (prev) => ({ ...prev, required: e.target.checked }))}
                    style={{ cursor: 'pointer' }}
                  />
                  <span style={{ fontSize: '12px', fontWeight: 600, color: '#334155' }}>Required</span>
                </label>

                <label style={{
                  ...checkboxLabelStyle,
                  backgroundColor: node.isNull ? '#fee2e2' : '#ffffff',
                  borderColor: node.isNull ? '#ef4444' : '#cbd5e1',
                }}>
                  <input
                    type="checkbox"
                    checked={Boolean(node.isNull)}
                    onChange={handleToggleNull}
                    style={{ cursor: 'pointer' }}
                  />
                  <span style={{ fontSize: '12px', fontWeight: 700, color: node.isNull ? '#dc2626' : '#64748b' }}>
                    Set Null
                  </span>
                </label>
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '12px', marginBottom: '12px', flexWrap: 'wrap' }}>
            {!isObjectOrArray && (
              <div style={{ flex: 1, minWidth: '180px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                <label style={fieldLabelStyle}>Default Value (dvalue)</label>
                {node.type === 'boolean' ? (
                  <select
                    value={String(node.dvalue)}
                    onChange={(e) => handleValueChange('dvalue', e.target.value === 'true')}
                    style={selectStyle}
                  >
                    <option value="true">true</option>
                    <option value="false">false</option>
                  </select>
                ) : (
                  <input
                    type={node.type === 'number' ? 'number' : 'text'}
                    value={node.dvalue ?? ''}
                    placeholder="Fallback dvalue"
                    onChange={(e) =>
                      handleValueChange('dvalue', node.type === 'number' ? Number(e.target.value) : e.target.value)
                    }
                    style={inputStyle}
                  />
                )}
              </div>
            )}

            <div style={{ flex: 1.5, minWidth: '220px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <label style={fieldLabelStyle}>Active Value</label>
              {node.isNull ? (
                <div style={nullValuePlaceholderStyle}>
                  <code>null</code>
                  <span style={{ fontSize: '11px', color: '#64748b', marginLeft: '8px' }}>
                    (Value is explicitly set to null)
                  </span>
                </div>
              ) : (
                <>
                  {node.type === 'string' && (
                    <input
                      type="text"
                      value={node.value ?? ''}
                      placeholder="e.g. ashok"
                      onChange={(e) => handleValueChange('value', e.target.value)}
                      style={inputStyle}
                    />
                  )}
                  {node.type === 'number' && (
                    <input
                      type="number"
                      value={node.value ?? 0}
                      onChange={(e) => handleValueChange('value', Number(e.target.value))}
                      style={inputStyle}
                    />
                  )}
                  {node.type === 'boolean' && (
                    <select
                      value={String(node.value)}
                      onChange={(e) => handleValueChange('value', e.target.value === 'true')}
                      style={selectStyle}
                    >
                      <option value="true">true</option>
                      <option value="false">false</option>
                    </select>
                  )}
                  {(node.type === 'function' || node.type === 'jsx') && (
                    <textarea
                      rows={3}
                      value={node.value ?? ''}
                      placeholder={`Enter raw ${node.type} code...`}
                      onChange={(e) => handleValueChange('value', e.target.value)}
                      style={codeTextAreaStyle}
                    />
                  )}
                  {isObjectOrArray && (
                    <span style={{ fontSize: '11px', color: '#64748b', lineHeight: '30px' }}>
                      (Value of Object/Array defined via nested children)
                    </span>
                  )}
                </>
              )}
            </div>
          </div>

          <div style={customMetaSectionStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#1e3a8a' }}>Custom Metadata Attributes</span>
              <button type="button" onClick={handleAddMetaItem} style={metaAddButtonStyle}>
                + Add Attribute
              </button>
            </div>

            {safeCustomMeta.length === 0 ? (
              <span style={{ fontSize: '11px', color: '#94a3b8' }}>No custom attributes added yet.</span>
            ) : (
              safeCustomMeta.map((meta) => {
                const metaKeyEmpty = !meta.key || !meta.key.trim();
                const customTemplate = renderCustomMetaAttribute
                  ? renderCustomMetaAttribute({
                      meta,
                      node,
                      onChangeValue: (newVal) => handleUpdateMetaItem(meta.id, 'value', newVal),
                      onChangeKey: (newKey) => handleUpdateMetaItem(meta.id, 'key', newKey),
                      onDelete: () => handleDeleteMetaItem(meta.id),
                    })
                  : null;

                return (
                  <div key={meta.id} style={{ display: 'flex', gap: '8px', marginTop: '8px', alignItems: 'center' }}>
                    <input
                      type="text"
                      placeholder="attr_name"
                      value={meta.key || ''}
                      onChange={(e) => handleUpdateMetaItem(meta.id, 'key', e.target.value)}
                      style={{ ...inputStyle, width: '140px', borderColor: metaKeyEmpty ? '#ef4444' : '#cbd5e1' }}
                    />
                    <div style={{ flex: 1 }}>
                      {customTemplate ? (
                        customTemplate
                      ) : (
                        <input
                          type="text"
                          placeholder="value"
                          value={meta.value || ''}
                          onChange={(e) => handleUpdateMetaItem(meta.id, 'value', e.target.value)}
                          style={{ ...inputStyle, width: '100%' }}
                        />
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteMetaItem(meta.id)}
                      style={{ ...actionButtonStyle, color: '#ef4444', border: 'none', background: 'transparent' }}
                    >
                      ✕
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* RECURSIVE RENDER WITH SAFETY ARRAY VERIFICATIONS */}
      {isObjectOrArray && node.isExpanded && safeChildren.length > 0 && (
        <div style={{ borderLeft: '2px solid #e2e8f0', marginLeft: '8px' }}>
          {safeChildren.map((child, idx) => (
            <SchemaNodeRow
              key={child.id}
              node={child}
              depth={depth + 1}
              parentType={node.type}
              index={idx}
              parentId={node.id}
              onUpdate={onUpdate}
              onDelete={onDelete}
              onAddChild={onAddChild}
              entireTree={entireTree}
              isSiblingKeyDuplicateFn={isSiblingKeyDuplicateFn}
              onReorder={onReorder}
              onReparent={onReparent}
              draggedParentType={draggedParentType}
              setDraggedParentType={setDraggedParentType}
              searchQuery={searchQuery}
              renderCustomMetaAttribute={renderCustomMetaAttribute}
              getTypeIcon={getTypeIcon}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const nullBadgeStyle = {
  fontSize: '10px',
  fontFamily: 'monospace',
  backgroundColor: '#fee2e2',
  color: '#b91c1c',
  padding: '2px 6px',
  borderRadius: '4px',
  fontWeight: 'bold',
  border: '1px solid #fca5a5',
};

const nullValuePlaceholderStyle = {
  display: 'flex',
  alignItems: 'center',
  padding: '6px 10px',
  backgroundColor: '#f1f5f9',
  border: '1px dashed #94a3b8',
  borderRadius: '4px',
  fontSize: '12px',
  color: '#0f172a',
};

const rowStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '8px 12px',
  borderRadius: '6px',
  border: '1px solid #e2e8f0',
  transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
};

const labelTextStyle = {
  fontSize: '13px',
  fontFamily: 'monospace',
  whiteSpace: 'nowrap',
};

const typeIconStyle = {
  fontSize: '13px',
  userSelect: 'none',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: '18px',
  height: '18px',
};

const typeBadgeStyle = {
  fontSize: '11px',
  fontFamily: 'monospace',
  backgroundColor: '#f1f5f9',
  color: '#475569',
  padding: '2px 6px',
  borderRadius: '4px',
  border: '1px solid #e2e8f0',
};

const reqBadgeStyle = {
  fontSize: '10px',
  backgroundColor: '#fef3c7',
  color: '#92400e',
  padding: '2px 5px',
  borderRadius: '4px',
  fontWeight: 'bold',
  border: '1px solid #fde68a',
};

const editDrawerStyle = {
  background: '#f8fafc',
  padding: '12px 16px',
  borderRadius: '0 0 6px 6px',
  border: '1px solid #cbd5e1',
  borderTop: 'none',
  marginTop: '-1px',
};

const customMetaSectionStyle = {
  background: '#eff6ff',
  padding: '10px 12px',
  borderRadius: '6px',
  border: '1px solid #bfdbfe',
  marginTop: '8px',
};

const fieldLabelStyle = {
  fontSize: '11px',
  fontWeight: 600,
  color: '#64748b',
};

const dragHandleStyle = {
  cursor: 'grab',
  paddingRight: '4px',
  userSelect: 'none',
  fontSize: '15px',
  color: '#94a3b8',
};

const dropIndicatorStyle = {
  height: '4px',
  backgroundColor: '#3b82f6',
  borderRadius: '4px',
  margin: '6px 0',
  animation: 'pulseGlow 1.5s infinite ease-in-out',
};

const inputStyle = {
  padding: '6px 8px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  fontSize: '12px',
  fontFamily: 'monospace',
  boxSizing: 'border-box',
};

const selectStyle = {
  padding: '6px 8px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  fontSize: '12px',
  backgroundColor: '#ffffff',
  boxSizing: 'border-box',
};

const checkboxLabelStyle = {
  display: 'flex',
  alignItems: 'center',
  gap: '6px',
  padding: '6px 8px',
  background: '#ffffff',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  cursor: 'pointer',
  userSelect: 'none',
  height: '32px',
  boxSizing: 'border-box',
};

const codeTextAreaStyle = {
  width: '100%',
  fontFamily: 'monospace',
  fontSize: '11px',
  padding: '6px 8px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  backgroundColor: '#ffffff',
  resize: 'vertical',
  boxSizing: 'border-box',
};

const arrayBadgeStyle = {
  fontSize: '12px',
  fontWeight: 'bold',
  color: '#475569',
  padding: '2px 6px',
  background: '#f1f5f9',
  borderRadius: '4px',
};

const iconButtonStyle = {
  border: 'none',
  background: 'transparent',
  cursor: 'pointer',
  fontSize: '12px',
  padding: '2px 4px',
};

const actionButtonStyle = {
  padding: '4px 10px',
  borderRadius: '4px',
  border: '1px solid #cbd5e1',
  background: '#ffffff',
  cursor: 'pointer',
  fontSize: '12px',
  fontWeight: 600,
};

const metaAddButtonStyle = {
  background: '#2563eb',
  color: '#ffffff',
  border: 'none',
  borderRadius: '4px',
  fontSize: '10px',
  fontWeight: 'bold',
  padding: '3px 8px',
  cursor: 'pointer',
};
