// src/utils/schemaTree.js

export const ALPHANUMERIC_REGEX = /^[a-zA-Z0-9]*$/;

export const DATA_TYPES = [
  'string',
  'number',
  'boolean',
  'object',
  'array',
  'function',
  'jsx',
];

export const getDefaultValueForType = (type) => {
  switch (type) {
    case 'string':
      return '';
    case 'number':
      return 0;
    case 'boolean':
      return false;
    case 'function':
      return '() => {\n  return null;\n}';
    case 'jsx':
      return '<div className="custom-node">\n  <span>Rendered Item</span>\n</div>';
    case 'object':
    case 'array':
    default:
      return undefined;
  }
};

export const createDefaultNode = (key = '', type = 'string', overrides = {}) => {
  const initialDefault = getDefaultValueForType(type);
  return {
    id: typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID()
      : Math.random().toString(36).substring(2, 9),
    key,
    type,
    required: false,
    dvalue: initialDefault,
    value: initialDefault,
    customMeta: [], // Array of { id, key, value }
    children: type === 'object' || type === 'array' ? [] : undefined,
    isExpanded: true,
    showMetaSettings: false,
    ...overrides,
  };
};

// Immutably update a node
export const updateNode = (nodes, targetId, updater) => {
  return nodes.map((node) => {
    if (node.id === targetId) return updater(node);
    if (node.children) {
      return { ...node, children: updateNode(node.children, targetId, updater) };
    }
    return node;
  });
};

// Immutably delete a node
export const deleteNode = (nodes, targetId) => {
  return nodes
    .filter((node) => node.id !== targetId)
    .map((node) => ({
      ...node,
      children: node.children ? deleteNode(node.children, targetId) : undefined,
    }));
};

// Immutably add a child node
export const addChildNode = (nodes, parentId, newNode) => {
  return nodes.map((node) => {
    if (node.id === parentId) {
      return {
        ...node,
        isExpanded: true,
        children: [...(node.children || []), newNode],
      };
    }
    if (node.children) {
      return { ...node, children: addChildNode(node.children, parentId, newNode) };
    }
    return node;
  });
};

// Check if sibling key is already taken at the same depth
export const isSiblingKeyDuplicate = (nodes, targetId, newKey) => {
  const normalizedKey = (newKey || '').trim();
  if (!normalizedKey) return false;

  const targetIndex = nodes.findIndex((node) => node.id === targetId);
  if (targetIndex !== -1) {
    return nodes.some(
      (node) => node.id !== targetId && (node.key || '').trim() === normalizedKey
    );
  }

  for (const node of nodes) {
    if (node.children) {
      const isDuplicate = isSiblingKeyDuplicate(node.children, targetId, normalizedKey);
      if (isDuplicate) return true;
    }
  }
  return false;
};

// Comprehensive tree validation
export const isTreeValid = (nodes, parentType = 'object') => {
  for (const node of nodes) {
    if (parentType !== 'array') {
      if (!node.key || !node.key.trim()) return false;
      if (isSiblingKeyDuplicate(nodes, node.id, node.key)) return false;
    }
    if (node.customMeta && node.customMeta.some((meta) => !meta.key.trim())) {
      return false;
    }
    if (node.children && (node.type === 'object' || node.type === 'array')) {
      const childrenValid = isTreeValid(node.children, node.type);
      if (!childrenValid) return false;
    }
  }
  return true;
};

// Parse custom meta value into native JS primitive if applicable
const parseMetaValue = (val) => {
  const trimmed = String(val).trim();
  if (trimmed.toLowerCase() === 'true') return true;
  if (trimmed.toLowerCase() === 'false') return false;
  if (!isNaN(trimmed) && trimmed !== '') return Number(trimmed);
  return val;
};

// Serialize AST into JSON Schema Definition
export const serializeSchemaDefinition = (nodes, parentType = 'object') => {
  if (parentType === 'array') {
    return nodes.map((child) => {
      const base = {
        type: child.type,
        required: Boolean(child.required),
        dvalue: child.dvalue,
      };

      if (child.customMeta && child.customMeta.length > 0) {
        child.customMeta.forEach((meta) => {
          if (meta.key.trim()) {
            base[meta.key.trim()] = parseMetaValue(meta.value);
          }
        });
      }

      if (child.type === 'object' || child.type === 'array') {
        base.items = serializeSchemaDefinition(child.children || [], child.type);
      } else if (child.type === 'function') {
        base.code = child.value;
      } else if (child.type === 'jsx') {
        base.template = child.value;
      } else {
        base.value = child.value;
      }
      return base;
    });
  }

  const result = {};
  for (const node of nodes) {
    const key = node.key.trim() || `unnamed_${node.id.slice(0, 4)}`;
    const definition = {
      type: node.type,
      required: Boolean(node.required),
      dvalue: node.dvalue,
    };

    if (node.customMeta && node.customMeta.length > 0) {
      node.customMeta.forEach((meta) => {
        if (meta.key.trim()) {
          definition[meta.key.trim()] = parseMetaValue(meta.value);
        }
      });
    }

    if (node.type === 'object') {
      definition.properties = serializeSchemaDefinition(node.children || [], 'object');
    } else if (node.type === 'array') {
      definition.items = serializeSchemaDefinition(node.children || [], 'array');
    } else if (node.type === 'function') {
      definition.code = node.value;
    } else if (node.type === 'jsx') {
      definition.template = node.value;
    } else {
      definition.value = node.value;
    }

    result[key] = definition;
  }
  return result;
};

// DnD: Extract node from tree
export const extractNode = (nodes, targetId) => {
  let draggedNode = null;
  const filterTree = (list) => {
    return list
      .filter((node) => {
        if (node.id === targetId) {
          draggedNode = node;
          return false;
        }
        return true;
      })
      .map((node) => {
        if (node.children) {
          return { ...node, children: filterTree(node.children) };
        }
        return node;
      });
  };
  const cleanedTree = filterTree(nodes);
  return { cleanedTree, draggedNode };
};

// DnD: Reinsert at sibling index
export const insertNodeAtActiveLevel = (nodes, targetParentId, draggedNode, targetIndex) => {
  if (targetParentId === 'root') {
    const updated = [...nodes];
    updated.splice(targetIndex, 0, draggedNode);
    return updated;
  }
  return nodes.map((node) => {
    if (node.id === targetParentId) {
      const updatedChildren = [...(node.children || [])];
      updatedChildren.splice(targetIndex, 0, draggedNode);
      return { ...node, children: updatedChildren };
    }
    if (node.children) {
      return {
        ...node,
        children: insertNodeAtActiveLevel(node.children, targetParentId, draggedNode, targetIndex),
      };
    }
    return node;
  });
};

// DnD: Reparent node into an object or array
export const reparentNode = (nodes, draggedId, targetParentId) => {
  const { cleanedTree, draggedNode } = extractNode(nodes, draggedId);
  if (!draggedNode) return nodes;

  const sanitizeNodeForParent = (node, destinationType) => {
    if (destinationType === 'array') {
      return { ...node, key: '' };
    }
    if (destinationType === 'object' && !node.key.trim()) {
      return { ...node, key: `prop${Math.random().toString(36).substring(2, 6)}` };
    }
    return node;
  };

  if (targetParentId === 'root') {
    return [...cleanedTree, sanitizeNodeForParent(draggedNode, 'object')];
  }

  const insertRecursive = (treeList) => {
    return treeList.map((node) => {
      if (node.id === targetParentId) {
        return {
          ...node,
          isExpanded: true,
          children: [...(node.children || []), sanitizeNodeForParent(draggedNode, node.type)],
        };
      }
      if (node.children) {
        return { ...node, children: insertRecursive(node.children) };
      }
      return node;
    });
  };

  return insertRecursive(cleanedTree);
};

// Search: Check if node or subtree matches
export const nodeMatchesQuery = (node, query) => {
  if (!query) return true;
  const q = query.toLowerCase();

  const keyMatch = (node.key || '').toLowerCase().includes(q);
  const typeMatch = (node.type || '').toLowerCase().includes(q);
  const valueMatch = String(node.value || '').toLowerCase().includes(q);
  const metaMatch = node.customMeta && node.customMeta.some(
    (meta) => (meta.key || '').toLowerCase().includes(q) || String(meta.value || '').toLowerCase().includes(q)
  );

  if (keyMatch || typeMatch || valueMatch || metaMatch) return true;

  if (node.children && node.children.length > 0) {
    return node.children.some((child) => nodeMatchesQuery(child, query));
  }
  return false;
};

// Search: Expand parent nodes of matches
export const expandMatchingNodes = (nodes, query) => {
  if (!query) return nodes;
  return nodes.map((node) => {
    const hasMatch = nodeMatchesQuery(node, query);
    if (node.children) {
      return {
        ...node,
        isExpanded: hasMatch ? true : node.isExpanded,
        children: expandMatchingNodes(node.children, query),
      };
    }
    return node;
  });
};
